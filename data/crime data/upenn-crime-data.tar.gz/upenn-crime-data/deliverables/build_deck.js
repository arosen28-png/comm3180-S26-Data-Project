// UPenn / University City Crime Data Findings — Slide deck builder
const pptxgen = require("pptxgenjs");

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3" x 7.5"
pres.title = "University City Crime Data — 10-Year Findings";
pres.author = "UPenn / University City Crime Data Project";

// --- Palette ---
const C = {
  bg:        "FFFFFF",
  dark:      "1A1A2E", // charcoal-navy for bookends + headers
  text:      "1A1A2E",
  muted:     "5C6B73", // secondary text, axis labels
  rule:      "E2E2E8", // subtle dividers
  accent:    "C44536", // alarming / spike (used sparingly)
  context:   "82A0AA", // secondary line in multi-line charts
  green:     "3A7D44", // "down from peak" positive context
  bgDark:    "1A1A2E",
  textOnDark:"FFFFFF",
};

const HEADER_FONT = "Georgia";
const BODY_FONT   = "Calibri";

// --- Helper: title with consistent left vertical accent (visual motif) ---
function addTitle(slide, text, opts = {}) {
  const y = opts.y ?? 0.5;
  // thin vertical accent rule on left
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.5, y: y + 0.05, w: 0.06, h: 0.65,
    fill: { color: C.accent }, line: { color: C.accent, width: 0 },
  });
  slide.addText(text, {
    x: 0.7, y: y, w: 12.2, h: 0.8,
    fontFace: HEADER_FONT, fontSize: 28, bold: true, color: C.text,
    margin: 0, valign: "top",
  });
  // optional eyebrow above title
  if (opts.eyebrow) {
    slide.addText(opts.eyebrow, {
      x: 0.7, y: y - 0.32, w: 12.2, h: 0.3,
      fontFace: BODY_FONT, fontSize: 11, bold: true, color: C.muted,
      charSpacing: 4, margin: 0,
    });
  }
}

function addFooter(slide, slideNum, totalSlides) {
  slide.addText("University City Crime Data · 2015–2025", {
    x: 0.5, y: 7.15, w: 8, h: 0.25,
    fontFace: BODY_FONT, fontSize: 9, color: C.muted, margin: 0,
  });
  slide.addText(`${slideNum} / ${totalSlides}`, {
    x: 11.8, y: 7.15, w: 1.0, h: 0.25,
    fontFace: BODY_FONT, fontSize: 9, color: C.muted, align: "right", margin: 0,
  });
}

const TOTAL = 13;

// =========================================================================
// SLIDE 1 — Title
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bgDark };

  // accent rule
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.8, y: 3.0, w: 0.8, h: 0.06,
    fill: { color: C.accent }, line: { color: C.accent, width: 0 },
  });

  s.addText("UNIVERSITY CITY CRIME DATA", {
    x: 0.8, y: 2.4, w: 12, h: 0.5,
    fontFace: BODY_FONT, fontSize: 13, bold: true, color: C.accent,
    charSpacing: 8, margin: 0,
  });

  s.addText("Ten years of numbers,\nfour different geographies.", {
    x: 0.8, y: 3.2, w: 12, h: 1.8,
    fontFace: HEADER_FONT, fontSize: 48, bold: true, color: C.textOnDark,
    margin: 0, paraSpaceAfter: 0,
  });

  s.addText("Penn Clery · Pennsylvania UCR · PPD Citywide · UPennAlerts", {
    x: 0.8, y: 5.3, w: 12, h: 0.4,
    fontFace: BODY_FONT, fontSize: 14, color: "9BA8B0", italic: true, margin: 0,
  });

  s.addText("Compiled from public sources · 2015–2025", {
    x: 0.8, y: 6.7, w: 12, h: 0.3,
    fontFace: BODY_FONT, fontSize: 10, color: "6E7E87", charSpacing: 3, margin: 0,
  });
}

// =========================================================================
// SLIDE 2 — The four geographies
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Four geographies. Don't mix them up.", { eyebrow: "FRAMING" });

  s.addText(
    "Every crime stat about \"Penn\" or \"University City\" is measured against a different boundary. These numbers are not interchangeable.",
    { x: 0.7, y: 1.45, w: 12.0, h: 0.6,
      fontFace: BODY_FONT, fontSize: 14, color: C.muted, italic: true, margin: 0 }
  );

  // 4 cards in a 2x2 grid
  const cards = [
    { t: "Penn Patrol Zone",   sub: "30th–43rd, Market–Baltimore",
      d: "Penn Police primary jurisdiction. Reported in the Annual Security & Fire Safety Report (Clery)." },
    { t: "Clery \"Campus\"",     sub: "Penn-owned + adjacent public",
      d: "Federal definition. Narrower than the Patrol Zone — only Penn-owned/controlled buildings and immediately adjacent public property." },
    { t: "Pennsylvania UCR",   sub: "Broader Penn-policed area",
      d: "State-mandated reporting. Counts Part 1 offenses, normalized by full-time equivalent (FTE) students + employees." },
    { t: "PPD Citywide",       sub: "All of Philadelphia",
      d: "Philadelphia Police Department. Used here for citywide context (homicides), not for direct comparison to Penn data." },
  ];
  const gridX = [0.7, 7.0];
  const gridY = [2.1, 4.6];
  const cardW = 5.6, cardH = 2.3;

  cards.forEach((c, i) => {
    const x = gridX[i % 2], y = gridY[Math.floor(i / 2)];
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h: cardH,
      fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 0.06, h: cardH,
      fill: { color: C.accent }, line: { color: C.accent, width: 0 },
    });
    s.addText(c.t, {
      x: x + 0.25, y: y + 0.2, w: cardW - 0.4, h: 0.45,
      fontFace: HEADER_FONT, fontSize: 19, bold: true, color: C.text, margin: 0,
    });
    s.addText(c.sub, {
      x: x + 0.25, y: y + 0.7, w: cardW - 0.4, h: 0.3,
      fontFace: BODY_FONT, fontSize: 11, bold: true, color: C.accent,
      charSpacing: 3, margin: 0,
    });
    s.addText(c.d, {
      x: x + 0.25, y: y + 1.05, w: cardW - 0.4, h: cardH - 1.2,
      fontFace: BODY_FONT, fontSize: 12.5, color: C.muted, margin: 0,
    });
  });

  addFooter(s, 2, TOTAL);
}

// =========================================================================
// SLIDE 3 — Data sources & approach
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Data sources & approach", { eyebrow: "METHODOLOGY" });

  // Left column — sources
  s.addText("SOURCES", {
    x: 0.7, y: 1.55, w: 6, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });

  const sources = [
    { t: "Penn Annual Security & Fire Safety Reports", d: "2020 ASR (covers 2017–19), 2022 ASR (2019–21), 2025 ASR (2022–24). Clery counts in Penn Patrol Zone." },
    { t: "Penn Pennsylvania UCR submissions", d: "Annual Part 1 offense counts + FTE denominators, 2017–2024." },
    { t: "Philadelphia Police Department", d: "Citywide homicide totals, 2007–2025 (YTD)." },
    { t: "UPennAlerts archive", d: "Real-time campus alerts, partial coverage 2019–2021." },
  ];
  let y = 1.95;
  sources.forEach((src) => {
    s.addText(src.t, {
      x: 0.7, y, w: 6.0, h: 0.32,
      fontFace: BODY_FONT, fontSize: 13, bold: true, color: C.text, margin: 0,
    });
    s.addText(src.d, {
      x: 0.7, y: y + 0.32, w: 6.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 11.5, color: C.muted, margin: 0,
    });
    y += 1.15;
  });

  // Right column — approach
  s.addShape(pres.shapes.RECTANGLE, {
    x: 7.2, y: 1.55, w: 5.6, h: 5.0,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });

  s.addText("APPROACH", {
    x: 7.45, y: 1.75, w: 5.2, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });

  s.addText([
    { text: "10 years targeted", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "2015–2024 for Clery (2015–16 backfill noted as gap); 2017–2024 for PA UCR; 2007–2025 for citywide homicides.", options: { fontSize: 12, color: C.muted, breakLine: true, paraSpaceAfter: 8 } },

    { text: "Authoritative when revised", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "When ASRs revise prior-year numbers, the most recent ASR's figure is used. 2019 was revised between the 2020 and 2022 reports.", options: { fontSize: 12, color: C.muted, breakLine: true, paraSpaceAfter: 8 } },

    { text: "No cross-geography math", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "Patrol Zone, Clery campus, PA UCR area, and citywide totals are presented separately. No ratios or growth rates across boundaries.", options: { fontSize: 12, color: C.muted, breakLine: true, paraSpaceAfter: 8 } },

    { text: "Reproducible", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "All CSVs + Python build script published alongside this deck.", options: { fontSize: 12, color: C.muted } },
  ], {
    x: 7.45, y: 2.15, w: 5.2, h: 4.3,
    fontFace: BODY_FONT, valign: "top", margin: 0,
  });

  addFooter(s, 3, TOTAL);
}

// =========================================================================
// SLIDE 4 — Citywide context: Philly homicides 2015–2025
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Homicides peaked in 2021. Down 60% since.", { eyebrow: "PHILADELPHIA · CITYWIDE CONTEXT" });

  s.addText(
    "Crime perceptions on campus are shaped by what's happening across Philadelphia. Citywide homicides ran from a 2021 peak of 562 to roughly 222 in 2025 — among the steepest drops in any major U.S. city.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  // Line chart
  const homicideLabels = ["2015","2016","2017","2018","2019","2020","2021","2022","2023","2024","2025"];
  const homicideValues = [280, 277, 315, 353, 356, 499, 562, 516, 410, 269, 222];

  s.addChart(pres.charts.LINE, [{
    name: "Homicides (citywide)", labels: homicideLabels, values: homicideValues,
  }], {
    x: 0.7, y: 2.4, w: 8.5, h: 4.4,
    chartColors: [C.accent],
    lineSize: 3, lineSmooth: false,
    lineDataSymbol: "circle", lineDataSymbolSize: 8,
    lineDataSymbolLineColor: C.accent,
    chartArea: { fill: { color: C.bg } },
    plotArea:  { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 10, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 10, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.text, dataLabelFontSize: 9, dataLabelPosition: "t",
    showLegend: false,
  });

  // Right callout cards
  s.addShape(pres.shapes.RECTANGLE, {
    x: 9.5, y: 2.4, w: 3.3, h: 2.05,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });
  s.addText("562", {
    x: 9.5, y: 2.5, w: 3.3, h: 0.9,
    fontFace: HEADER_FONT, fontSize: 56, bold: true, color: C.accent, align: "center", margin: 0,
  });
  s.addText("homicides in 2021", {
    x: 9.5, y: 3.45, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 12, bold: true, color: C.text, align: "center", margin: 0,
  });
  s.addText("All-time city record", {
    x: 9.5, y: 3.78, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, color: C.muted, align: "center", italic: true, margin: 0,
  });

  s.addShape(pres.shapes.RECTANGLE, {
    x: 9.5, y: 4.7, w: 3.3, h: 2.1,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });
  s.addText("−60%", {
    x: 9.5, y: 4.8, w: 3.3, h: 0.9,
    fontFace: HEADER_FONT, fontSize: 56, bold: true, color: C.green, align: "center", margin: 0,
  });
  s.addText("from 2021 peak to 2025", {
    x: 9.5, y: 5.75, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 12, bold: true, color: C.text, align: "center", margin: 0,
  });
  s.addText("YTD figures, ~222 in 2025", {
    x: 9.5, y: 6.08, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, color: C.muted, align: "center", italic: true, margin: 0,
  });

  addFooter(s, 4, TOTAL);
}

// =========================================================================
// SLIDE 5 — Penn Patrol Zone violent crime trends (Clery)
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Violent crime in the Patrol Zone is roughly flat.", { eyebrow: "PENN CLERY · VIOLENT CRIME" });

  s.addText(
    "Eight years of Clery data from the Penn Patrol Zone (30th–43rd, Market–Baltimore). No clear secular trend — year-to-year noise dominates. Robbery has trended down; aggravated assault has trended modestly up.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.65,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  const labels = ["2017","2018","2019","2020","2021","2022","2023","2024"];

  s.addChart(pres.charts.LINE, [
    { name: "Robbery",            labels, values: [28, 26, 21, 20, 20, 39, 26, 15] },
    { name: "Aggravated Assault", labels, values: [18, 10, 24, 17, 32, 19, 31, 28] },
    { name: "Rape",               labels, values: [9,  7,  2,  4, 10,  4,  5,  8] },
    { name: "Domestic Violence",  labels, values: [14, 10, 14, 11, 6,  6,  3, 18] },
  ], {
    x: 0.7, y: 2.3, w: 12.0, h: 4.5,
    chartColors: [C.accent, C.dark, C.context, "B58A2E"],
    lineSize: 2.5, lineSmooth: false,
    lineDataSymbol: "circle", lineDataSymbolSize: 7,
    chartArea: { fill: { color: C.bg } },
    plotArea:  { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 11, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 11, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showLegend: true, legendPos: "b", legendFontSize: 11, legendColor: C.muted, legendFontFace: BODY_FONT,
  });

  addFooter(s, 5, TOTAL);
}

// =========================================================================
// SLIDE 6 — 2024 Motor Vehicle Theft spike
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "The 2024 MVT spike isn't a Penn problem.", { eyebrow: "PENN CLERY · PROPERTY CRIME" });

  s.addText(
    "Motor vehicle thefts in the Patrol Zone jumped from 13 (2017) to 208 (2024) — a 16× increase. Same trajectory hit every U.S. city: a 2022 TikTok exposed how to start Hyundais and Kias without a key.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  // Column chart
  s.addChart(pres.charts.BAR, [{
    name: "Motor Vehicle Theft", labels: ["2017","2018","2019","2020","2021","2022","2023","2024"],
    values: [13, 16, 13, 31, 40, 58, 85, 208],
  }], {
    x: 0.7, y: 2.4, w: 8.5, h: 4.4,
    barDir: "col",
    chartColors: [C.accent],
    chartArea: { fill: { color: C.bg } },
    plotArea:  { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 11, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 11, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.text, dataLabelFontSize: 10, dataLabelPosition: "outEnd",
    showLegend: false,
  });

  // Right pull-out
  s.addShape(pres.shapes.RECTANGLE, {
    x: 9.5, y: 2.4, w: 3.3, h: 4.4,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });
  s.addText("WHAT HAPPENED", {
    x: 9.7, y: 2.55, w: 3.0, h: 0.3,
    fontFace: BODY_FONT, fontSize: 10, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });
  s.addText("Hyundai/Kia\nignition flaw", {
    x: 9.7, y: 2.9, w: 3.0, h: 1.0,
    fontFace: HEADER_FONT, fontSize: 22, bold: true, color: C.text, margin: 0,
  });
  s.addText(
    "A 2022 TikTok showed how to start certain Hyundai and Kia models with a USB cable. Thefts of those models rose 1,000%+ nationally. Recall and software fix rolled out late 2023.",
    { x: 9.7, y: 4.05, w: 3.0, h: 1.6,
      fontFace: BODY_FONT, fontSize: 11.5, color: C.muted, margin: 0 }
  );
  s.addText("FOUNDER LENS", {
    x: 9.7, y: 5.75, w: 3.0, h: 0.25,
    fontFace: BODY_FONT, fontSize: 10, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });
  s.addText(
    "Read the spike before reacting to it. The trend shape matches the U.S. baseline — not a Penn-specific safety crisis.",
    { x: 9.7, y: 6.05, w: 3.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 11.5, color: C.text, italic: true, margin: 0 }
  );

  addFooter(s, 6, TOTAL);
}

// =========================================================================
// SLIDE 7 — PA UCR broader trend
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Broader area: Part 1 offenses up since 2020.", { eyebrow: "PENNSYLVANIA UCR · PART 1 OFFENSES" });

  s.addText(
    "Penn's PA UCR submissions cover a broader area than the Patrol Zone. Total Part 1 offenses dropped during COVID, then climbed steadily — 593 (2020) → 1,204 (2024). FTE denominators also shifted as students returned.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  // Combo: Part 1 offenses (column) + FTE (line, secondary axis)
  s.addChart(pres.charts.LINE, [{
    name: "Total Part 1 offenses",
    labels: ["2017","2018","2019","2020","2021","2022","2023","2024"],
    values: [703, 829, 813, 593, 655, 896, 1132, 1204],
  }], {
    x: 0.7, y: 2.4, w: 8.5, h: 4.4,
    chartColors: [C.accent],
    lineSize: 3, lineSmooth: false,
    lineDataSymbol: "circle", lineDataSymbolSize: 8,
    chartArea: { fill: { color: C.bg } },
    plotArea:  { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 11, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 11, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.text, dataLabelFontSize: 10, dataLabelPosition: "t",
    showLegend: false,
  });

  // Right column callouts
  s.addShape(pres.shapes.RECTANGLE, {
    x: 9.5, y: 2.4, w: 3.3, h: 2.05,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });
  s.addText("593", {
    x: 9.5, y: 2.5, w: 3.3, h: 0.9,
    fontFace: HEADER_FONT, fontSize: 52, bold: true, color: C.dark, align: "center", margin: 0,
  });
  s.addText("Part 1 offenses · 2020", {
    x: 9.5, y: 3.45, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 12, bold: true, color: C.text, align: "center", margin: 0,
  });
  s.addText("COVID-era low", {
    x: 9.5, y: 3.78, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, color: C.muted, align: "center", italic: true, margin: 0,
  });

  s.addShape(pres.shapes.RECTANGLE, {
    x: 9.5, y: 4.7, w: 3.3, h: 2.1,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });
  s.addText("1,204", {
    x: 9.5, y: 4.8, w: 3.3, h: 0.9,
    fontFace: HEADER_FONT, fontSize: 52, bold: true, color: C.accent, align: "center", margin: 0,
  });
  s.addText("Part 1 offenses · 2024", {
    x: 9.5, y: 5.75, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 12, bold: true, color: C.text, align: "center", margin: 0,
  });
  s.addText("2× the 2020 low", {
    x: 9.5, y: 6.08, w: 3.3, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, color: C.muted, align: "center", italic: true, margin: 0,
  });

  addFooter(s, 7, TOTAL);
}

// =========================================================================
// SLIDE 8 — COVID anomaly (2020)
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "2020 broke every category.", { eyebrow: "THE COVID ANOMALY" });

  s.addText(
    "Don't draw trends across it. When students disappear, the underlying activity that generates the data disappears too. 2020 should be treated as a discontinuity, not a data point.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  // Three callout cards horizontally
  const anomalies = [
    { stat: "−83%", lbl: "Liquor disciplinary",  detail: "371 (2019) → 62 (2020). Empty bars and dorms — there was nobody to write up." },
    { stat: "+138%", lbl: "Motor vehicle theft", detail: "13 (2019) → 31 (2020). Cars sat parked and unattended for months." },
    { stat: "−27%", lbl: "PA UCR Part 1 total",  detail: "813 (2019) → 593 (2020). Reduced foot traffic, reduced opportunity." },
  ];
  const cardW = 4.0, cardH = 3.6;
  const startX = 0.65, gap = 0.25;

  anomalies.forEach((a, i) => {
    const x = startX + i * (cardW + gap);
    const y = 2.4;
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h: cardH,
      fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: cardW, h: 0.06,
      fill: { color: C.accent }, line: { color: C.accent, width: 0 },
    });
    s.addText(a.stat, {
      x: x + 0.2, y: y + 0.4, w: cardW - 0.4, h: 1.4,
      fontFace: HEADER_FONT, fontSize: 64, bold: true, color: C.accent, align: "center", margin: 0,
    });
    s.addText(a.lbl, {
      x: x + 0.2, y: y + 1.95, w: cardW - 0.4, h: 0.4,
      fontFace: BODY_FONT, fontSize: 15, bold: true, color: C.text, align: "center", margin: 0,
    });
    s.addText(a.detail, {
      x: x + 0.3, y: y + 2.45, w: cardW - 0.6, h: 1.0,
      fontFace: BODY_FONT, fontSize: 12, color: C.muted, align: "center", margin: 0,
    });
  });

  s.addText(
    "Implication: any year-over-year analysis using 2020 as a base or comparison year will overstate or understate the underlying trend. Compare 2019 to 2022+ instead.",
    { x: 0.7, y: 6.4, w: 12.0, h: 0.5,
      fontFace: BODY_FONT, fontSize: 12, color: C.text, italic: true, margin: 0 }
  );

  addFooter(s, 8, TOTAL);
}

// =========================================================================
// SLIDE 9 — Sex offenses & hate crimes
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Sex offenses & hate crimes: small-N.", { eyebrow: "PENN CLERY · LOWER-VOLUME CATEGORIES" });

  s.addText(
    "Watch year-to-year. These categories have small annual counts, so single-year movements can look dramatic without being statistically meaningful. Trend lines are more honest than headline numbers.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  // Two charts side by side
  s.addText("Rape (Patrol Zone)", {
    x: 0.7, y: 2.3, w: 6.0, h: 0.4,
    fontFace: BODY_FONT, fontSize: 13, bold: true, color: C.text, margin: 0,
  });
  s.addChart(pres.charts.BAR, [{
    name: "Rape", labels: ["2017","2018","2019","2020","2021","2022","2023","2024"],
    values: [9, 7, 2, 4, 10, 4, 5, 8],
  }], {
    x: 0.7, y: 2.7, w: 6.0, h: 4.0, barDir: "col",
    chartColors: [C.accent],
    chartArea: { fill: { color: C.bg } }, plotArea: { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 10, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 10, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.text, dataLabelFontSize: 10, dataLabelPosition: "outEnd",
    showLegend: false,
  });

  s.addText("Hate Crimes (Patrol Zone)", {
    x: 6.95, y: 2.3, w: 6.0, h: 0.4,
    fontFace: BODY_FONT, fontSize: 13, bold: true, color: C.text, margin: 0,
  });
  s.addChart(pres.charts.BAR, [{
    name: "Hate Crimes", labels: ["2017","2018","2019","2020","2021","2022","2023","2024"],
    values: [1, 0, 0, 2, 2, 1, 5, 0],
  }], {
    x: 6.95, y: 2.7, w: 6.0, h: 4.0, barDir: "col",
    chartColors: [C.dark],
    chartArea: { fill: { color: C.bg } }, plotArea: { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 10, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 10, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.text, dataLabelFontSize: 10, dataLabelPosition: "outEnd",
    showLegend: false,
  });

  addFooter(s, 9, TOTAL);
}

// =========================================================================
// SLIDE 10 — Liquor disciplinary referrals (the campus-life signal)
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Liquor referrals: a proxy for campus presence.", { eyebrow: "PENN CLERY · DISCIPLINARY ACTIONS" });

  s.addText(
    "Liquor disciplinary referrals are less about drinking trends and more about how many students are physically on campus and how aggressively conduct staff enforce. Useful as an attendance proxy.",
    { x: 0.7, y: 1.5, w: 12.0, h: 0.7,
      fontFace: BODY_FONT, fontSize: 13, color: C.muted, italic: true, margin: 0 }
  );

  s.addChart(pres.charts.BAR, [{
    name: "Liquor Disciplinary",
    labels: ["2017","2018","2019","2020","2021","2022","2023","2024"],
    values: [374, 366, 371, 62, 445, 136, 110, 217],
  }], {
    x: 0.7, y: 2.4, w: 8.5, h: 4.4, barDir: "col",
    chartColors: [C.dark],
    chartArea: { fill: { color: C.bg } }, plotArea: { fill: { color: C.bg } },
    catAxisLabelColor: C.muted, catAxisLabelFontSize: 11, catAxisLabelFontFace: BODY_FONT,
    valAxisLabelColor: C.muted, valAxisLabelFontSize: 11, valAxisLabelFontFace: BODY_FONT,
    valGridLine: { color: C.rule, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.text, dataLabelFontSize: 10, dataLabelPosition: "outEnd",
    showLegend: false,
  });

  // Right side annotations
  s.addShape(pres.shapes.RECTANGLE, {
    x: 9.5, y: 2.4, w: 3.3, h: 4.4,
    fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
  });
  s.addText("READ-ACROSS", {
    x: 9.7, y: 2.55, w: 3.0, h: 0.3,
    fontFace: BODY_FONT, fontSize: 10, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });
  s.addText([
    { text: "2020: 62", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "Campus emptied. Floor at COVID lockdown.", options: { fontSize: 11.5, color: C.muted, breakLine: true, paraSpaceAfter: 8 } },
    { text: "2021: 445", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "Return-to-campus rebound — highest in the series.", options: { fontSize: 11.5, color: C.muted, breakLine: true, paraSpaceAfter: 8 } },
    { text: "2022–23 dip", options: { bold: true, fontSize: 14, color: C.text, breakLine: true } },
    { text: "Likely a policy/enforcement shift, not a behavior shift.", options: { fontSize: 11.5, color: C.muted } },
  ], {
    x: 9.7, y: 2.95, w: 3.0, h: 3.7,
    fontFace: BODY_FONT, valign: "top", margin: 0,
  });

  addFooter(s, 10, TOTAL);
}

// =========================================================================
// SLIDE 11 — Caveats: what this data doesn't show
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "What this data doesn't show.", { eyebrow: "CAVEATS" });

  const caveats = [
    { t: "Reporting bias", d: "Sex offenses, domestic violence, and hate crimes are under-reported across all jurisdictions. A drop in counts can reflect lower reporting, not lower incidence." },
    { t: "Geographic gaps",  d: "Crimes one block outside the Patrol Zone don't appear in Clery — but students still experience them. The boundary is administrative, not behavioral." },
    { t: "Severity is flat",  d: "A robbery and an attempted robbery count the same. No injury severity, no weapon detail, no outcome tracking." },
    { t: "Definitions change", d: "Clery categories were redefined in 2014 (VAWA amendments). Older years aren't strictly comparable to newer ones." },
    { t: "2015–16 Clery gap", d: "ASRs from those years are not in Penn's current archive. Backfill via the federal Campus Safety database (linked in repo)." },
    { t: "Lag",   d: "Clery numbers for year N are published in October of year N+1. The freshest year here is 2024." },
  ];

  // 2x3 grid of cards
  const colW = 4.0, rowH = 1.65;
  const startX = 0.65, startY = 1.6, gapX = 0.25, gapY = 0.2;
  caveats.forEach((c, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = startX + col * (colW + gapX);
    const y = startY + row * (rowH + gapY);
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: colW, h: rowH,
      fill: { color: "F7F7F9" }, line: { color: C.rule, width: 0.5 },
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 0.06, h: rowH,
      fill: { color: C.accent }, line: { color: C.accent, width: 0 },
    });
    s.addText(c.t, {
      x: x + 0.25, y: y + 0.18, w: colW - 0.4, h: 0.35,
      fontFace: HEADER_FONT, fontSize: 16, bold: true, color: C.text, margin: 0,
    });
    s.addText(c.d, {
      x: x + 0.25, y: y + 0.6, w: colW - 0.4, h: rowH - 0.7,
      fontFace: BODY_FONT, fontSize: 11.5, color: C.muted, margin: 0,
    });
  });

  s.addText(
    "If you want to know whether a place feels safe, this dataset is a starting point — not an answer.",
    { x: 0.7, y: 5.45, w: 12, h: 0.5,
      fontFace: BODY_FONT, fontSize: 13, color: C.text, italic: true, margin: 0 }
  );

  addFooter(s, 11, TOTAL);
}

// =========================================================================
// SLIDE 12 — Key takeaways (dark)
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bgDark };

  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.8, y: 0.55, w: 0.06, h: 0.7,
    fill: { color: C.accent }, line: { color: C.accent, width: 0 },
  });
  s.addText("KEY TAKEAWAYS", {
    x: 0.95, y: 0.5, w: 12, h: 0.4,
    fontFace: BODY_FONT, fontSize: 12, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });
  s.addText("Five things to remember.", {
    x: 0.95, y: 0.85, w: 12, h: 0.7,
    fontFace: HEADER_FONT, fontSize: 32, bold: true, color: C.textOnDark, margin: 0,
  });

  const takeaways = [
    { n: "01", t: "Pick the right boundary.",       d: "Patrol Zone, Clery campus, PA UCR area, citywide — they are not interchangeable. Quote one, never average them." },
    { n: "02", t: "Violent crime is roughly flat.", d: "In the Patrol Zone, year-to-year noise dominates. No clear secular trend up or down across 2017–2024." },
    { n: "03", t: "MVT spike is a national story.", d: "The 16× jump in motor vehicle theft mirrors the U.S. Hyundai/Kia trend. Don't read it as a Penn-specific signal." },
    { n: "04", t: "Citywide context is improving.", d: "Philadelphia homicides are down ~60% from the 2021 peak. Campus perception lags reality." },
    { n: "05", t: "2020 is a discontinuity.",       d: "Treat COVID as a break in the series. Compare 2019 to 2022+, not to 2020." },
  ];

  let y = 2.0;
  takeaways.forEach((t) => {
    s.addText(t.n, {
      x: 0.95, y, w: 0.9, h: 0.7,
      fontFace: HEADER_FONT, fontSize: 28, bold: true, color: C.accent, margin: 0,
    });
    s.addText(t.t, {
      x: 1.95, y, w: 11, h: 0.42,
      fontFace: BODY_FONT, fontSize: 16, bold: true, color: C.textOnDark, margin: 0,
    });
    s.addText(t.d, {
      x: 1.95, y: y + 0.42, w: 11, h: 0.5,
      fontFace: BODY_FONT, fontSize: 12.5, color: "B8C0C8", margin: 0,
    });
    y += 0.95;
  });
}

// =========================================================================
// SLIDE 13 — Sources & methodology
// =========================================================================
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  addTitle(s, "Sources & repository", { eyebrow: "REPRODUCIBILITY" });

  s.addText("PRIMARY SOURCES", {
    x: 0.7, y: 1.55, w: 6, h: 0.3,
    fontFace: BODY_FONT, fontSize: 11, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });

  const refs = [
    { name: "Penn Annual Security & Fire Safety Reports (2020, 2022, 2025)",
      url:  "publicsafety.upenn.edu" },
    { name: "Penn Pennsylvania UCR submissions",
      url:  "publicsafety.upenn.edu (annual filings, 2017–2024)" },
    { name: "Philadelphia Police Department crime stats",
      url:  "phillypolice.com / Open Data Philly" },
    { name: "U.S. Department of Education Campus Safety database",
      url:  "ope.ed.gov/campussafety/  (for 2015–16 backfill)" },
    { name: "UPennAlerts archive",
      url:  "Internal Penn alert log, 2019–2021 (partial)" },
  ];
  let y = 1.95;
  refs.forEach((r) => {
    s.addText(r.name, {
      x: 0.7, y, w: 12, h: 0.32,
      fontFace: BODY_FONT, fontSize: 13, bold: true, color: C.text, margin: 0,
    });
    s.addText(r.url, {
      x: 0.7, y: y + 0.32, w: 12, h: 0.3,
      fontFace: "Consolas", fontSize: 11, color: C.muted, margin: 0,
    });
    y += 0.78;
  });

  // Repository box
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.7, y: 5.95, w: 12.1, h: 1.0,
    fill: { color: C.bgDark }, line: { color: C.bgDark, width: 0 },
  });
  s.addText("REPOSITORY", {
    x: 0.95, y: 6.05, w: 4, h: 0.25,
    fontFace: BODY_FONT, fontSize: 10, bold: true, color: C.accent, charSpacing: 4, margin: 0,
  });
  s.addText("All CSVs, build script, Jupyter notebook, and compiled XLSX shipped alongside this deck.", {
    x: 0.95, y: 6.32, w: 11.8, h: 0.55,
    fontFace: BODY_FONT, fontSize: 13, color: C.textOnDark, margin: 0,
  });

  addFooter(s, 13, TOTAL);
}

// --- Write file ---
pres.writeFile({ fileName: "/home/claude/deck/upenn_crime_findings.pptx" })
  .then((file) => console.log("Wrote:", file));
