# University City Crime Data

A 10-year compilation of crime statistics in and around the University of Pennsylvania, drawn from Penn Clery reports, Penn's Pennsylvania UCR submissions, Philadelphia Police Department citywide data, and UPennAlerts. CSVs, build script, exploratory notebooks, slide deck, and a full documentation suite.

## Headlines

- Violent crime in the Penn Patrol Zone is roughly flat across 2017–2024.
- Citywide Philadelphia homicides are down ~60% from the 2021 peak.
- The 2024 motor vehicle theft spike is a national Hyundai/Kia trend, not a Penn-specific issue.
- 2020 is a discontinuity, not a data point — compare 2019 to 2022+.
- Patrol Zone, Clery campus, PA UCR area, and citywide totals measure different things and shouldn't be averaged.

Full prose findings: [`docs/FINDINGS.md`](docs/FINDINGS.md).

## Repository structure

```
upenn-crime-data/
├── README.md                  # This file
├── LICENSE                    # MIT
├── CHANGELOG.md
├── CONTRIBUTING.md
├── requirements.txt           # Python deps
├── build_xlsx.py              # Compiles CSVs into the workbook
│
├── data/                      # Source-of-truth CSVs
│   ├── penn_clery_annual.csv
│   ├── penn_pa_ucr.csv
│   ├── ppd_homicides_citywide.csv
│   ├── upennalerts.csv
│   └── data_sources.csv
│
├── output/                    # Regenerated artifacts
│   └── upenn_crime_data.xlsx
│
├── notebooks/
│   ├── 01_explore.ipynb
│   └── 02_geography_comparisons.ipynb
│
├── docs/                      # Documentation
│   ├── FINDINGS.md
│   ├── METHODOLOGY.md
│   ├── DATA_DICTIONARY.md
│   ├── GLOSSARY.md
│   ├── SOURCES.md
│   ├── CAVEATS.md
│   └── FAQ.md
│
└── deliverables/              # Stand-alone outputs
    ├── upenn_crime_findings.pptx
    ├── upenn_crime_findings.pdf
    └── build_deck.js
```

## Quick start

```bash
git clone <this-repo>
cd upenn-crime-data
pip install -r requirements.txt
python build_xlsx.py
jupyter notebook notebooks/01_explore.ipynb
```

## Documentation

| Document | Purpose |
|----------|---------|
| [`docs/FINDINGS.md`](docs/FINDINGS.md) | Full prose write-up of what the data shows. |
| [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md) | How the data was collected, processed, and decisions made. |
| [`docs/DATA_DICTIONARY.md`](docs/DATA_DICTIONARY.md) | Column-by-column reference for every CSV. |
| [`docs/GLOSSARY.md`](docs/GLOSSARY.md) | Terminology (Clery, UCR, FTE, etc.). |
| [`docs/SOURCES.md`](docs/SOURCES.md) | Full list of sources with URLs and retrieval dates. |
| [`docs/CAVEATS.md`](docs/CAVEATS.md) | Limitations — what the data does NOT show. |
| [`docs/FAQ.md`](docs/FAQ.md) | Anticipated questions, short answers. |

## Geographies (don't mix them up)

The single most important framing point. There are four boundaries in play:

| Geography | Description | Source |
|-----------|-------------|--------|
| **Penn Patrol Zone** | 30th–43rd, Market–Baltimore. Penn Police primary jurisdiction. | Penn ASR (Clery) |
| **Clery campus** | Penn-owned/controlled buildings + immediately adjacent public property. Narrower than Patrol Zone. | Federal Clery Act |
| **Pennsylvania UCR area** | Broader area, normalized per 100k FTE. | Penn ASR (PA UCR table) |
| **PPD citywide** | All of Philadelphia. Used for context only. | PPD / Open Data Philly |

Counts across these are not interchangeable. See [`docs/GLOSSARY.md`](docs/GLOSSARY.md) and the framing slide in [`deliverables/upenn_crime_findings.pptx`](deliverables/upenn_crime_findings.pptx).

## Coverage

| Series | Range | Source |
|--------|-------|--------|
| Penn Clery | 2017–2024 | 2020, 2022, 2025 ASRs |
| Penn PA UCR | 2017–2024 | 2020, 2022, 2025 ASRs |
| PPD homicides | 2007–2025 (YTD) | PPD |
| UPennAlerts | 2019–2021 (partial) | DP / archives |

**Known gaps** (documented in [`docs/CAVEATS.md`](docs/CAVEATS.md)):
- 2015–2016 Clery — backfill via federal Campus Safety database.
- UPennAlerts pre-2019 and post-2021 — Penn doesn't maintain a public archive.

## Contributing

Bug reports (data discrepancies vs. source PDFs) and 2015–2016 backfills are welcome. See [`CONTRIBUTING.md`](CONTRIBUTING.md).

## License

MIT. The compilation, structure, and documentation are released under the MIT License. The underlying data is public record. See [`LICENSE`](LICENSE).

## Citation

If you use this dataset:

> University City Crime Data (2026). Compilation of Penn Clery, Pennsylvania UCR, PPD, and UPennAlerts data, 2007–2025.

For academic use, cite the primary sources directly — see [`docs/SOURCES.md`](docs/SOURCES.md).
