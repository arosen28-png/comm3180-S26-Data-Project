# Data Dictionary

Column-by-column reference for every CSV in `data/`.

---

## `data/penn_clery_annual.csv`

Long-format Clery Act crime counts for the Penn Patrol Zone, one row per (year, crime_type).

| Column | Type | Description |
|--------|------|-------------|
| `year` | integer | Calendar year the crimes occurred. Range: 2017–2024. |
| `crime_type` | string | Clery category. Lowercase, snake_case (e.g., `aggravated_assault`, `motor_vehicle_theft`). See "Crime types" below. |
| `count` | integer | Number of incidents reported in the Patrol Zone for that year and category. |
| `source_asr` | string | Which Annual Security Report the figure came from: `2020_ASR`, `2022_ASR`, or `2025_ASR`. When figures were revised across editions, the most recent ASR's number is used. |
| `note` | string | Free-text caveat, blank for most rows. Used to flag revisions, classification changes, or data anomalies. |

### Crime types observed

**Violent / person crimes:** `murder`, `rape`, `fondling`, `incest`, `statutory_rape`, `robbery`, `aggravated_assault`, `domestic_violence`, `dating_violence`, `stalking`

**Property crimes:** `burglary`, `motor_vehicle_theft`, `arson`

**Hate crimes:** `hate_crimes_total` (Penn does not consistently break out by bias category in the public ASR tables)

**Disciplinary actions / arrests:** `liquor_disciplinary`, `liquor_arrests`, `drug_disciplinary`, `drug_arrests`, `weapons_disciplinary`, `weapons_arrests`

### Geographic note

The Penn Clery report aggregates incidents across three Clery geography buckets: "On-Campus," "Non-Campus Property," and "Public Property." This file collapses those three into a single Patrol Zone count per year/category. If you need the breakdown, you'll have to go back to the source ASRs.

---

## `data/penn_pa_ucr.csv`

Wide-format Pennsylvania Uniform Crime Reporting Act table, one row per year. This is the broader-area data, normalized against an FTE denominator.

| Column | Type | Description |
|--------|------|-------------|
| `year` | integer | Calendar year. Range: 2017–2024. |
| `fte_population` | integer | Full-time-equivalent students + employees in the reporting area. The denominator for any per-capita rate calculation. |
| `criminal_homicide` | integer | Murder + non-negligent manslaughter. |
| `forcible_rape` | integer | Rape (Part 1 offense definition). |
| `robbery` | integer | Robbery count. |
| `aggravated_assault` | integer | Aggravated assault count. |
| `simple_assault` | integer | Simple assault count (NOT a Part 1 offense; reported separately). |
| `burglary` | integer | Burglary count. |
| `theft` | integer | Larceny-theft (excluding motor vehicle theft). |
| `motor_vehicle_theft` | integer | Completed MVT count. |
| `attempted_mv_theft` | integer | Attempted MVT count, where reported. Often `0`. |
| `arson` | integer | Arson count. |
| `total_part1` | integer | Sum of Part 1 offenses (homicide + rape + robbery + agg. assault + burglary + theft + MVT + arson). Does **not** include simple assault. |
| `source_asr` | string | Which ASR this row was extracted from. |

### Notes

- **FTE population is volatile.** It dropped from 65,322 in 2019 to 42,424 in 2021 as students went home during COVID. Per-capita comparisons across that period are misleading.
- **`total_part1` is reproducible.** Sum the eight Part 1 columns and you should get the total. If you don't, file a bug.

---

## `data/ppd_homicides_citywide.csv`

Citywide homicide totals from the Philadelphia Police Department. Used for context, not for direct comparison with Penn data.

| Column | Type | Description |
|--------|------|-------------|
| `year` | integer | Calendar year. Range: 2007–2025. |
| `homicides` | integer | PPD-reported total homicides for the year. 2025 reflects YTD at time of compilation. |
| `source` | string | Source of the figure (`phillypolice.com` for most rows). |

### Notes

- 2025 is YTD and will increase by year end.
- PPD's count classification has been consistent through this period (criminal homicide). Justifiable homicides and self-defense rulings are excluded.

---

## `data/upennalerts.csv`

Counts of UPennAlerts notifications. **Partial coverage only — 2019–2021.**

| Column | Type | Description |
|--------|------|-------------|
| `year` | integer | Calendar year. Range: 2019–2021. |
| `upennalert_count` | integer | Number of UPennAlerts issued that year. **Treat as a floor, not a true total** (Penn does not maintain a complete public archive). |
| `source` | string | Source of the count. |

### Why the data is incomplete

UPennAlerts are issued in real time and posted to a public-facing system, but Penn does not publish an annual archive. The counts here come from third-party tracking by the Daily Pennsylvanian. A complete time series would require systematic scraping of the alert system.

---

## `data/data_sources.csv`

Metadata for every primary source used in the dataset.

| Column | Type | Description |
|--------|------|-------------|
| `source_id` | string | Internal short ID (e.g., `2020_ASR`). Referenced in other CSVs' `source_asr` column. |
| `description` | string | Human-readable description of what the source covers. |
| `url` | string | Direct URL to the source document. |
| `retrieval_date` | date (ISO 8601) | When this URL was retrieved. |
| `geography_definition` | string | What geographic area the source covers (essential — see `docs/GLOSSARY.md`). |

---

## Conventions across all files

- **Encoding:** UTF-8.
- **Line endings:** LF (Unix). Git config: `text=auto`.
- **Date format:** ISO 8601 (`YYYY-MM-DD`) where applicable.
- **Missing values:** empty string (not `NaN`, not `null`, not `-1`).
- **Integers:** plain integers, no thousand separators, no quotation marks.
