# Caveats & Limitations

What this dataset cannot tell you, and where to be careful.

---

## 1. Geographic boundaries are administrative, not behavioral

The Penn Patrol Zone ends at 43rd Street. A robbery on 44th Street does not appear in Penn's Clery report — but a Penn student walking home there is no less likely to experience it, and no less affected if they do.

The same applies to time-of-day and circumstance. Clery counts an incident regardless of whether the victim was a student, employee, visitor, or unaffiliated person passing through. You cannot use this data to estimate "crimes against Penn students" specifically.

**Practical implication:** Don't use Patrol Zone counts as a proxy for "how safe Penn students are." It is one input, not the answer.

---

## 2. Reporting bias is real and asymmetric

Clery and UCR data measure *reported* crimes. The gap between crimes that occur and crimes that get reported is significant for several categories:

- **Sex offenses** are estimated to be reported at roughly 25–30% of incidence in U.S. surveys.
- **Domestic violence** is similarly under-reported.
- **Hate crimes** are under-reported AND inconsistently classified (whether an incident counts as "hate-motivated" is a judgment call).
- **Theft** under $50 often isn't reported because there's no point — no expectation of recovery.

A drop in Clery counts can mean (a) fewer incidents, (b) fewer reports, or (c) a classification shift. This dataset cannot distinguish between the three.

---

## 3. Definitions changed in 2014

The Violence Against Women Act (VAWA) reauthorization in 2013 amended the Clery Act, with implementation in the 2014 reporting year. Major changes:

- **Domestic violence, dating violence, and stalking** became separate Clery categories. They didn't exist in pre-2014 data.
- **The rape definition broadened.** Pre-2014 Clery rape required force; the post-2014 definition matches the FBI's revised definition (any non-consensual sexual penetration).

**Practical implication:** Pre-2014 and post-2014 Clery numbers are NOT directly comparable for sex offenses or interpersonal violence.

---

## 4. Severity is not captured

A robbery and an attempted robbery count the same. An aggravated assault that resulted in hospitalization counts the same as one that resulted in a bruise. A burglary of $50 counts the same as a burglary of $50,000.

This dataset has no severity dimension. To analyze severity, you would need incident-level data — which is not what Penn publishes.

---

## 5. The 2015–2016 gap

Penn's current public archive of ASRs starts with the 2017 reporting year (published in 2018). The 2018 and 2019 ASRs (covering 2015 and 2016 respectively) are not available at `publicsafety.upenn.edu` at time of compilation.

Backfill is available via the federal Campus Safety database (`ope.ed.gov/campussafety/`), which collects Clery filings from all institutions receiving federal aid. We did not use this backfill in the primary CSVs because (a) we wanted Penn's own published data as the source of truth, and (b) federal aggregates can include classification differences from later Penn revisions.

If you need 2015–2016 numbers, pull them from the federal database and add a `source` value distinguishing them from Penn-direct rows.

---

## 6. UPennAlerts coverage is partial

UPennAlerts are real-time campus safety notifications sent during active incidents (shootings, robberies in progress, etc.). Penn does not maintain a public archive of historical alerts.

The 2019–2021 counts in `data/upennalerts.csv` come from third-party tracking by The Daily Pennsylvanian and similar outlets. Treat these as a floor: actual alert counts may be higher. Do not use this series for trend analysis.

---

## 7. 2020 is a discontinuity

COVID broke every category in different directions:

- **Liquor disciplinary referrals** dropped ~83% (campus was empty).
- **Motor vehicle theft** rose ~138% (cars sat parked unattended for months).
- **Total Part 1 offenses** dropped ~27% (less foot traffic, fewer opportunities).

Trend lines drawn through 2020 will be wrong in both directions depending on the category. Compare 2019 to 2022+ instead.

---

## 8. The 2024 motor vehicle theft spike is national, not local

The 16× increase in motor vehicle theft in the Patrol Zone (13 in 2017 → 208 in 2024) is real, but it tracks the U.S. Hyundai/Kia immobilizer-defect trend that hit every major city. It is NOT a Penn-specific safety crisis. Read the spike in national context.

A software fix and class-action settlement rolled out in late 2023. Watch the 2025 ASR (publishing October 2026) to see whether the fix moves the curve.

---

## 9. Hate crime category breakdowns are not captured

Penn reports hate crimes in aggregate (`hate_crimes_total`) but does not consistently disclose the bias category (race, religion, sexual orientation, etc.) in the public ASR tables. Where bias category breakdowns are available in the source PDFs, they're inconsistent enough across years to make tracking unreliable.

This dataset captures totals only.

---

## 10. The PA UCR FTE denominator is volatile

Penn's FTE population (the rate denominator) shifted dramatically across the time series:

- 2019: 65,322 (pre-COVID peak)
- 2021: 42,424 (COVID trough — students sent home)
- 2024: 46,877 (post-COVID baseline)

Per-capita rate calculations across this period will be misleading. We preserve both the count and the FTE denominator so users can compute rates explicitly when they want them, with eyes open.

---

## 11. Data lag

| Series | Publication lag |
|--------|-----------------|
| Clery (annual) | ~10 months (year N publishes October of N+1) |
| PA UCR (annual) | Same as Clery (published together) |
| PPD year-end | 1–3 months after year-end |
| UPennAlerts | Real-time but not annually compiled |

The freshest year in this dataset is 2024 for Clery and PA UCR, and 2025 YTD for PPD.

---

## 12. This is not an academic study

There is no IRB, no peer review, no statistical hypothesis testing. The findings document (`docs/FINDINGS.md`) is descriptive analysis, not inferential statistics.

If you need to cite something for academic purposes, cite the primary sources directly (the Penn ASRs, PPD reports, etc.).

---

## What this dataset IS good for

Despite the limitations above, this is a useful resource for:

- **Long-form context.** Anyone trying to understand campus crime trends without cherry-picking a year.
- **Reproducibility.** Every count traces back to a specific PDF page.
- **Geographic clarity.** The four-boundary framing prevents the most common analytical errors.
- **A starting point for further work.** Anyone wanting to layer in incident-level analysis, comparative work across schools, or temporal modeling can use this as a clean base.
