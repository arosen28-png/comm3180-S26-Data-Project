# Findings

A 10-year look at crime statistics in and around the University of Pennsylvania, drawing on Penn Clery reports, Penn's Pennsylvania UCR submissions, Philadelphia Police Department citywide data, and UPennAlerts.

This document is the prose companion to the slide deck (`deliverables/upenn_crime_findings.pptx`). The data, scripts, and source materials are all in this repo.

---

## Bottom line

1. **Pick the right boundary.** Patrol Zone, Clery campus, PA UCR area, and citywide totals each measure something different. They cannot be averaged or compared as if they were the same thing.
2. **Violent crime in the Penn Patrol Zone has been roughly flat** across 2017–2024. Year-to-year noise dominates; there is no clear secular trend up or down.
3. **The 2024 motor vehicle theft spike is a national story, not a Penn story.** It tracks the U.S. Hyundai/Kia trend that started in 2022.
4. **Citywide context is improving.** Philadelphia homicides are down roughly 60% from the 2021 peak. Campus perception lags reality.
5. **2020 is a discontinuity, not a data point.** Treat COVID as a break in every series. Compare 2019 to 2022+, not to 2020.

---

## 1. Geography matters more than the numbers

The single most common mistake in conversations about "Penn crime" is comparing numbers from different geographies as if they were the same thing. There are four boundaries in play here:

- **Penn Patrol Zone** — 30th to 43rd Street, Market Street to Baltimore Avenue. The area Penn Police patrols as primary jurisdiction. This is what the Clery report calls "non-campus" + "public property" + "on-campus" combined.
- **Clery "campus"** — A federal definition. Penn-owned or controlled buildings, plus immediately adjacent public property. Narrower than the Patrol Zone.
- **Pennsylvania UCR area** — Reported under state law. Counts Part 1 offenses across the area Penn covers, normalized per 100k full-time-equivalent (FTE) students and employees.
- **PPD citywide** — All of Philadelphia. Used here for context only, not for direct comparison to Penn data.

A robbery one block outside the Patrol Zone shows up in PPD data but not in Penn Clery. A property crime inside a Penn dorm shows up in both Clery and PA UCR. The differences matter and the analysis below keeps each geography separate.

---

## 2. Citywide context: Philadelphia homicides, 2015–2025

Philadelphia ran a homicide crisis from 2020 through 2022, with a peak of 562 killings in 2021 — the city's all-time record. The drop since has been one of the steepest in any major U.S. city.

| Year | Homicides |
|------|-----------|
| 2015 | 280 |
| 2016 | 277 |
| 2017 | 315 |
| 2018 | 353 |
| 2019 | 356 |
| 2020 | 499 |
| 2021 | **562** (peak) |
| 2022 | 516 |
| 2023 | 410 |
| 2024 | 269 |
| 2025 | 222 (YTD) |

That's roughly a 60% reduction from peak to 2025. The reasons are contested — improved clearance rates, post-pandemic normalization, social services investment, hot-spot policing — but the trend is real and consistent across PPD and independent trackers.

Why this matters for Penn: campus safety perceptions are anchored to citywide news cycles. The headline-grabbing 2020–22 period coincided with the years most current undergrads experienced as their formative impression of the city. The reality on the ground in 2025–26 is materially different.

---

## 3. Penn Patrol Zone: violent crime is flat

The Clery report covers eight years (2017–2024) of violent and property crime in the Patrol Zone. Aggregating the violent categories:

| Year | Robbery | Agg. Assault | Rape | Domestic Violence |
|------|---------|--------------|------|-------------------|
| 2017 | 28 | 18 | 9 | 14 |
| 2018 | 26 | 10 | 7 | 10 |
| 2019 | 21 | 24 | 2 | 14 |
| 2020 | 20 | 17 | 4 | 11 |
| 2021 | 20 | 32 | 10 | 6 |
| 2022 | 39 | 19 | 4 | 6 |
| 2023 | 26 | 31 | 5 | 3 |
| 2024 | 15 | 28 | 8 | 18 |

There is no clear trend. Robbery has trended modestly down (28 → 15 from 2017 to 2024). Aggravated assault has trended modestly up (18 → 28). Rape and domestic violence move within a narrow band, with year-to-year movement that's not statistically distinguishable from noise given the small counts.

The honest read: **the Patrol Zone is no more dangerous in 2024 than it was in 2017, on aggregate violent crime.** Anyone telling you otherwise is either cherry-picking a year or comparing across different geographies.

---

## 4. The 2024 motor vehicle theft spike

The most dramatic-looking number in the Clery data is motor vehicle theft, which jumped from 13 in 2017 to 208 in 2024 — a 16× increase.

| Year | MVT in Patrol Zone |
|------|--------------------|
| 2017 | 13 |
| 2018 | 16 |
| 2019 | 13 |
| 2020 | 31 |
| 2021 | 40 |
| 2022 | 58 |
| 2023 | 85 |
| 2024 | 208 |

This is not a Penn-specific phenomenon. In 2022, a TikTok exposed how to hot-wire certain Hyundai and Kia models that lacked engine immobilizers. Thefts of those models rose more than 1,000% nationally over the next 24 months. Insurance carriers in some states stopped writing new policies on affected vehicles. A software fix and class-action settlement rolled out in late 2023.

The Patrol Zone trajectory matches the U.S. baseline. Plotting the same series for any major city's downtown shows a similar shape. It is correct to say MVT in University City spiked. It is incorrect to read that spike as a Penn safety crisis.

---

## 5. Pennsylvania UCR: the broader area is up

Penn's PA UCR submissions cover a broader geographic area than the Patrol Zone. Total Part 1 offenses (the violent + serious property categories the FBI tracks):

| Year | FTE | Part 1 offenses |
|------|-----|-----------------|
| 2017 | 52,175 | 703 |
| 2018 | 57,191 | 829 |
| 2019 | 65,322 | 813 |
| 2020 | 54,814 | 593 (COVID) |
| 2021 | 42,424 | 655 |
| 2022 | 43,606 | 896 |
| 2023 | 45,018 | 1,132 |
| 2024 | 46,877 | 1,204 |

Two things are happening at once:

- **The COVID drop is real but temporary.** 2020 was the lowest year. By 2022, totals had recovered to pre-pandemic levels.
- **Post-2022 escalation is largely property crime.** The MVT story above is the single biggest contributor to the 2023–24 increase.

Note the FTE denominator: it dropped sharply in 2021 as students were sent home, then rebuilt. Per-capita rate calculations across this period are misleading.

---

## 6. The COVID anomaly

2020 broke every category in different directions. Three illustrations:

- **Liquor disciplinary referrals: −83%** (371 in 2019 → 62 in 2020). With campus closed, there was no one to write up.
- **Motor vehicle theft: +138%** (13 → 31). Cars sat parked and unattended for months.
- **PA UCR Part 1 total: −27%** (813 → 593). Reduced foot traffic, reduced opportunity.

The implication for any analysis: do not draw trend lines through 2020. It is a discontinuity. Compare 2019 to 2022 or later to gauge underlying trends.

---

## 7. Lower-volume categories

Sex offenses and hate crimes have small annual counts, which makes them especially vulnerable to misreading.

**Rape (Patrol Zone)**: 9, 7, 2, 4, 10, 4, 5, 8 across 2017–2024. The 2019 figure of 2 is conspicuously low and was revised between the 2020 ASR and the 2022 ASR. With single-digit counts, year-to-year movement of 100%+ is not necessarily statistically meaningful.

**Hate crimes (Patrol Zone)**: 1, 0, 0, 2, 2, 1, 5, 0. The 2023 figure of 5 reflects, in part, classification of incidents related to the campus tensions of that academic year. The 2024 zero should not be read as a sustained reversal — single-year counts in this small a series can flip on one or two incidents.

For both categories, under-reporting is a known problem across all U.S. jurisdictions. A drop in counts can reflect lower reporting rates, not lower incidence.

---

## 8. Liquor disciplinary referrals as a presence proxy

| Year | Liquor referrals |
|------|------------------|
| 2017 | 374 |
| 2018 | 366 |
| 2019 | 371 |
| 2020 | 62 |
| 2021 | 445 |
| 2022 | 136 |
| 2023 | 110 |
| 2024 | 217 |

This series is less about drinking trends and more about (a) how many students were physically on campus, and (b) how aggressively conduct staff enforced. The 2020 floor reflects an empty campus. The 2021 spike reflects the return-to-campus rebound. The 2022–23 dip is most plausibly an enforcement policy shift, not a behavior shift.

Useful as a sanity check on whether the rest of the data reflects normal campus activity.

---

## 9. What this data does not show

Six things to keep in mind:

1. **Reporting bias.** Sex offenses, domestic violence, and hate crimes are systematically under-reported. A drop in counts can reflect lower reporting, not lower incidence.
2. **Geographic gaps.** Crimes one block outside the Patrol Zone don't appear in Clery — but students still experience them. The boundary is administrative, not behavioral.
3. **No severity dimension.** A robbery and an attempted robbery count the same. No injury severity, no weapon detail, no outcome tracking.
4. **Definitions change.** Clery categories were redefined in 2014 under the VAWA amendments. Earlier years aren't strictly comparable to newer ones.
5. **2015–16 Clery gap.** ASRs for those years are not in Penn's current archive. Backfill is available via the federal Campus Safety database (linked in `docs/SOURCES.md`).
6. **Lag.** Clery numbers for year N are published in October of year N+1. The freshest year in this dataset is 2024.

If you want to know whether a place feels safe, this dataset is a starting point — not an answer.
