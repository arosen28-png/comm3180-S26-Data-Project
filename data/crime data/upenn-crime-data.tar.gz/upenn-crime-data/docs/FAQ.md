# FAQ

Anticipated questions, with short answers.

---

### Is Penn safer than it used to be?

It depends what you mean. **In the Patrol Zone**, violent crime is roughly flat across 2017–2024 — robbery has trended modestly down, aggravated assault modestly up. **Citywide**, Philadelphia is materially safer in 2025 than in 2021 (homicides down ~60% from peak). Property crime, specifically motor vehicle theft, has spiked nationally.

There is no single "is Penn safer" answer because there is no single boundary or category that captures it.

---

### Why does the 2024 Clery report show a huge motor vehicle theft jump?

Because in 2022 a TikTok showed how to start certain Hyundai and Kia models without a key. Thefts of those models rose more than 1,000% nationally. Penn's Patrol Zone tracked the national trend. The spike isn't Penn-specific.

A software fix and class-action settlement rolled out in late 2023. Watch the 2025 ASR for whether the curve flattens.

---

### Can I compare Penn's numbers to another school's?

Carefully. Two issues:

1. **Geographic boundaries differ.** Penn's Clery campus is a different shape from, say, Columbia's or Yale's. A school in a sprawling rural campus has more "Clery campus" area than an urban school packed into a few blocks.
2. **Reporting practices differ.** Some schools have stricter classification practices than others. Aggregated comparisons miss this.

Use the federal Campus Safety database (`ope.ed.gov/campussafety/`) as a starting point if you want to compare, but don't take rankings at face value.

---

### Why isn't 2015 or 2016 in here?

Penn's current public archive at `publicsafety.upenn.edu` starts with the 2018 ASR (covering 2017). The 2018 and 2019 ASRs (which would cover 2015 and 2016) aren't currently posted. The federal Campus Safety database has these years if you want to backfill.

---

### Why is 2020 so weird?

COVID. Campus emptied, behavior changed, reporting changed. Don't draw trend lines through 2020. See `docs/CAVEATS.md` for the breakdown.

---

### Are these numbers Penn's official figures?

The Clery and PA UCR counts are transcribed directly from Penn's published Annual Security Reports. The PPD homicide totals are from PPD's published data. The UPennAlerts counts are from third-party tracking (Penn doesn't publish an annual UPennAlerts archive).

If you find a discrepancy between a number in this repo and a number in the source PDF, file an issue.

---

### Can I use this for a school project / paper / article?

Yes. The data is public. We'd appreciate a citation (see `docs/SOURCES.md`). For academic citations, cite the primary sources directly.

---

### How often will this be updated?

Penn's ASR for the prior year publishes each October. The plan is to update this repo each November after the new ASR is parsed. PPD year-end totals get added in early January. There is no commitment — this is a personal project.

---

### Why not include incident-level data?

Two reasons:

1. **Penn doesn't publish incident-level data.** ASRs only give annual aggregate counts.
2. **PPD does** (via Open Data Philly), but cross-referencing it to a specific Penn-relevant subset is a separate project. If someone wants to layer that in, the existing structure of this repo can support it cleanly — see `docs/CONTRIBUTING.md`.

---

### What about UPennAlerts? They feel really frequent.

The dataset's UPennAlerts coverage (2019–2021) is partial because Penn doesn't maintain a public archive. Real-time perception ("I get alerts constantly") is hard to validate against actual frequency without a complete archive.

If you want to build that archive, scrape the alerts system and contribute. Until then, the count series here should be treated as a floor, not a true total.

---

### Is the slide deck the same as the findings document?

The slide deck (`deliverables/upenn_crime_findings.pptx`) is a visual summary. The findings document (`docs/FINDINGS.md`) is the prose version with the same structure but more depth.

---

### Why not break down by gender, race, time of day, etc.?

Penn doesn't publish those breakdowns at the annual aggregate level. PPD's incident-level data has more granularity but isn't included in this dataset.

---

### What's the difference between Clery and PA UCR?

Both are annual reports published by Penn. They cover different geographies and use different category definitions:

| | Clery | PA UCR |
|---|-------|--------|
| Geography | Patrol Zone | Broader area |
| Categories | Clery-defined (broader, includes hate crimes / VAWA categories) | FBI Part 1 categories |
| Denominator | None (just counts) | FTE population |
| Federal/state | Federal law | State law |

See `docs/GLOSSARY.md` for full definitions.

---

### Can I trust news headlines about Penn crime?

Headlines about specific incidents — yes, those incidents happened. Headlines that frame Penn as "increasingly dangerous" based on a single statistic — read with caution. Most use one geography, one category, one year-over-year comparison, and don't address whether the comparison is a trend or noise.

This dataset tries to provide the full picture so you can read those headlines critically.
