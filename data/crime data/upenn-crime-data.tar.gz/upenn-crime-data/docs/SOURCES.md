# Sources

Every primary source used in this dataset. Retrieval dates are when the URL was accessed during compilation.

---

## Penn Annual Security & Fire Safety Reports

| ID | Years covered | URL | Retrieved |
|----|---------------|-----|-----------|
| `2020_ASR` | 2017, 2018, 2019 | https://www.publicsafety.upenn.edu/files/2020_ASR_PENN.pdf | 2026-04-26 |
| `2022_ASR` | 2019, 2020, 2021 | https://www.publicsafety.upenn.edu/files/2022_ASR_PENN.pdf | 2026-04-26 |
| `2025_ASR` | 2022, 2023, 2024 | https://www.publicsafety.upenn.edu/files/2025_ASR_PENN.pdf | 2026-04-26 |

**Pattern:** Penn's ASRs are typically published in October each year, named `YYYY_ASR_PENN.pdf` and hosted at the URL above. Each ASR covers the three most recent calendar years.

**Why we used three different ASRs:** Each Clery year is reported in three consecutive ASRs (the year first published, plus two later updates). When figures differ between editions due to revision, we use the most recent ASR. See `docs/METHODOLOGY.md` for details.

---

## Penn Pennsylvania UCR table

The PA UCR table is published as a section inside Penn's ASRs (typically near the back, after the Clery table). Same source documents as above; the data is in tabular form within the PDF.

The 2025 ASR contains the cleanest historical PA UCR view (2022–2024). Earlier years come from the 2020 and 2022 ASRs.

---

## Philadelphia Police Department

| Source | URL | Retrieved |
|--------|-----|-----------|
| PPD crime statistics dashboard | https://www.phillypolice.com/crime-maps-stats | 2026-04-26 |
| Open Data Philly — crime incidents | https://opendataphilly.org/datasets/crime-incidents/ | 2026-04-26 |

PPD year-end homicide totals are published in their annual report and on the crime stats dashboard. Open Data Philly hosts the underlying incident-level data for any analyst who wants to slice differently.

---

## U.S. Department of Education Campus Safety database

| Source | URL | Retrieved |
|--------|-----|-----------|
| Federal Campus Safety database | https://ope.ed.gov/campussafety/ | 2026-04-26 |

Used here only as a recommended backfill source for 2015–2016 Clery data, which is not in Penn's current public archive. The federal database aggregates Clery filings from all U.S. institutions receiving Title IV funds.

---

## UPennAlerts

| Source | URL | Retrieved |
|--------|-----|-----------|
| UPennAlerts public-facing system | https://www.upennalerts.com (now redirected) | 2026-04-26 |
| Daily Pennsylvanian analytics | https://www.thedp.com (search "UPennAlerts") | 2026-04-26 |

Penn does not publish an annual archive of UPennAlerts. Counts in this dataset (2019–2021 only) come from third-party tracking by The Daily Pennsylvanian and other student outlets.

---

## Recent incident context (not in dataset)

The following are individually significant incidents referenced in news coverage during the compilation period. They are NOT in the structured dataset (which only contains aggregate annual counts), but are documented here for completeness.

- **November 11, 2025** — Shooting near 40th and Walnut Streets. Reported widely in Philadelphia press.
- **April 26, 2026** — Shooting near 40th and Sansom Streets. Reported in Philadelphia Inquirer and Daily Pennsylvanian.

These will appear in 2025 and 2026 Clery data when those ASRs publish in October 2026 and October 2027 respectively.

---

## How to cite

If you use this dataset:

> University City Crime Data (2026). Compilation of Penn Clery, Pennsylvania UCR, PPD, and UPennAlerts data, 2007–2025. Available at: [your-github-url]

For the underlying primary sources, cite the original documents (Penn ASRs, PPD reports, etc.) directly using the URLs above.

---

## Verifying the data

Every count in this dataset can be traced back to a specific PDF or web page via the `source_asr` (or `source`) column in the corresponding CSV. To verify:

1. Find the row of interest in `data/penn_clery_annual.csv` (or another CSV).
2. Read the `source_asr` value.
3. Look up the URL in this document or in `data/data_sources.csv`.
4. Open the source PDF.
5. Find the matching crime category and year in the source.

If a count in the CSV doesn't match what's in the source PDF, that's a bug. Open an issue on GitHub.
