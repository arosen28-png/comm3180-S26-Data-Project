# Glossary

Terminology used in this repo. Crime statistics have a vocabulary problem — the same word means different things to different agencies. This glossary defines terms as we use them here.

---

## Geography

**Penn Patrol Zone**
The area Penn Police covers as primary jurisdiction: 30th Street to 43rd Street, Market Street to Baltimore Avenue. This is the geography reported in Penn's Clery filings (combining "on-campus," "non-campus property," and "public property").

**Clery campus**
A federal definition under the Clery Act. Includes (1) buildings the institution owns or controls within a contiguous geographic area used for educational purposes, and (2) public property immediately adjacent to those buildings (sidewalks, streets). Narrower than the Patrol Zone.

**Pennsylvania UCR area**
The geographic area Penn covers under the Pennsylvania Uniform Crime Reporting Act. Broader than the Clery campus. Reported with FTE denominators rather than fixed boundaries.

**PPD jurisdiction**
The Philadelphia Police Department's jurisdiction is the entire City of Philadelphia.

**18th District (PPD)**
The PPD district covering most of West Philadelphia, including University City. Used for sub-citywide context, not in this dataset's primary tables.

**University City (neighborhood)**
A census-defined neighborhood in West Philadelphia. Population ~5,123 (2020 census). Distinct from "the area around Penn" colloquially called University City.

---

## Reporting frameworks

**Clery Act (1990)**
Federal law (20 U.S.C. § 1092(f)) requiring colleges that receive federal financial aid to disclose campus crime statistics annually. Reports are published every October 1, covering the prior calendar year. Defines specific crime categories (Clery categories) that may differ from FBI UCR categories.

**Annual Security Report (ASR)**
The document Clery requires institutions to publish each year. Includes crime statistics for the three most recent calendar years, plus campus security policies. Penn publishes its ASR at `publicsafety.upenn.edu`.

**Pennsylvania UCR Act**
State-level reporting law that requires Pennsylvania institutions to report Part 1 offense counts annually, normalized by FTE population. Penn's PA UCR table is published inside the same ASR document.

**FBI UCR (Uniform Crime Reporting)**
Federal program that aggregates police-reported crime statistics nationally. The "Part 1 offenses" classification originates here. Note: FBI replaced Summary Reporting System (SRS) with NIBRS (National Incident-Based Reporting System) in 2021, which changed some category definitions.

**NIBRS**
National Incident-Based Reporting System. The FBI's current crime reporting standard, replacing SRS in 2021. More granular than its predecessor.

**VAWA (Violence Against Women Act) Amendments**
2014 amendments to the Clery Act that added domestic violence, dating violence, and stalking as separate Clery categories. These categories don't exist in pre-2014 Clery data.

---

## Crime categories

**Part 1 offenses (FBI/UCR)**
Eight categories the FBI tracks as "serious crimes": criminal homicide, forcible rape, robbery, aggravated assault, burglary, larceny-theft, motor vehicle theft, arson. Sometimes called "index crimes." Simple assault is NOT a Part 1 offense.

**Violent crime (FBI definition)**
Subset of Part 1: criminal homicide + forcible rape + robbery + aggravated assault.

**Property crime (FBI definition)**
Subset of Part 1: burglary + larceny-theft + motor vehicle theft + arson.

**Robbery vs. theft**
Robbery involves force or threat of force against a person. Theft (larceny) does not. A snatch-and-grab is a robbery; a pickpocketing is a theft.

**Burglary vs. theft**
Burglary requires unlawful entry into a structure with intent to commit a crime. Stealing from an unlocked car parked on the street is theft, not burglary. Stealing from a locked dorm room you broke into is burglary.

**Aggravated assault vs. simple assault**
Aggravated assault involves serious bodily injury, a weapon, or attempt to inflict either. Simple assault doesn't. Only aggravated assault is a Part 1 offense.

**Rape (Clery definition, post-2014)**
"Penetration, no matter how slight, of the vagina or anus with any body part or object, or oral penetration by a sex organ of another person, without the consent of the victim." This is broader than the pre-2014 Clery definition (which required force) and tracks the FBI's revised definition.

**Fondling**
Clery category for non-consensual sexual contact that does not meet the rape definition. Reported separately from rape.

**Hate crime**
Clery defines a hate crime as a criminal offense (from a specific list) that manifests evidence the victim was targeted based on race, religion, sexual orientation, gender, gender identity, ethnicity, national origin, or disability. The underlying crime (e.g., assault) is reported in its category PLUS counted again in the hate crime tally.

**Domestic violence / dating violence**
VAWA-era Clery categories. Reported as separate counts from assault, even when the underlying act is also assault.

---

## Disciplinary categories

**Liquor disciplinary referrals**
Students referred to campus conduct processes for alcohol violations, where no arrest occurred. A separate count from "Liquor Arrests."

**Liquor arrests**
Arrests by Penn Police or PPD for alcohol-related offenses (underage drinking, public intoxication, etc.). Distinct from disciplinary referrals.

**Drug disciplinary referrals / Drug arrests**
Same distinction, applied to drug offenses.

**Weapons disciplinary referrals / Weapons arrests**
Same distinction, applied to weapons offenses.

---

## Population / denominator terms

**FTE (Full-Time Equivalent)**
Standard higher-ed population measure. Counts each full-time student/employee as 1.0 and part-time as a fraction (typically 0.33). Used as the denominator for PA UCR rate calculations.

**Per 100k FTE**
Standard rate format: incidents per year per 100,000 FTE. Allows comparison across institutions of different sizes.

**Headcount**
Raw number of enrolled students or employees, regardless of full/part-time status. NOT used in this dataset's rate calculations.

---

## Process terms

**ASR revision**
When a later Annual Security Report republishes a prior year's count with a different number than the original ASR reported. Common cause: cases reclassified, additional reports filed late, or definitional changes. We use the most recent ASR's number as authoritative.

**Reporting lag**
The gap between when crimes occur and when they appear in published statistics. Clery year N is published in October of year N+1. PPD year-end totals are typically finalized 1-3 months after year-end. UPennAlerts are real-time but not annually compiled.

**Reporting bias / under-reporting**
The systematic gap between crimes that occur and crimes that get reported to authorities. Particularly significant for sex offenses, domestic violence, and hate crimes. Not measurable from this dataset alone.

---

## Things that sound related but aren't

**"Crime rate" (general)**
A loaded term. Could mean per-capita rate (incidents / population), per-FTE rate (PA UCR), or just a count. Always specify the denominator.

**"Safety" (perception)**
Not a measurable quantity in this dataset. Crime statistics measure reported incidents, not safety. The two are correlated but not the same.

**"Crime trend" (temporal)**
Requires more than two data points and a clear methodology to claim. A single-year increase or decrease is not a trend.
