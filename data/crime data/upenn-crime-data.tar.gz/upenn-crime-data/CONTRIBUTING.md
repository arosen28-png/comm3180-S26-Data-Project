# Contributing

This is a small personal project, not a community open-source effort. Contributions are welcome but kept simple.

## What's wanted

- **Bug reports.** If a count in a CSV doesn't match its source PDF, that's a bug. Open an issue with: the CSV row, the source PDF page reference, and the discrepancy.
- **Backfill.** 2015–2016 Clery data is missing. If you want to pull it from the federal Campus Safety database, follow the existing CSV schema and add a row to `data/data_sources.csv` documenting where you got it.
- **Comparable schools.** Adding a peer institutions context table (Columbia, Yale, etc.) would be useful but a separate effort.
- **UPennAlerts archive.** Currently only 2019–2021. A scraper or systematic archive would be useful.

## What's not wanted

- New crime categories invented by combining existing ones. Keep the source categorization.
- Cross-geography arithmetic in the CSVs. Per `docs/METHODOLOGY.md`, geographies stay separate.
- Pull requests that change the methodology without an issue discussion first.

## How to contribute

1. Open an issue describing what you want to add or fix.
2. If the issue is approved (or it's an obvious bug fix), open a pull request.
3. Pull requests should:
   - Match the existing CSV schema (see `docs/DATA_DICTIONARY.md`).
   - Update relevant docs (e.g., `docs/SOURCES.md` if you added a new source).
   - Update `CHANGELOG.md` under "Unreleased."
4. Re-run `python build_xlsx.py` and commit the regenerated `output/upenn_crime_data.xlsx`.

## Code style

- Python: follow [PEP 8](https://peps.python.org/pep-0008/). Keep it simple — this is a small project, not a framework.
- CSV: UTF-8, LF line endings, ISO 8601 dates, blank for missing values (not `NaN`).
- Markdown: GitHub-flavored. Tables for structured data. Don't over-format.

## Issues to avoid

- **Don't auto-format CSVs through Excel.** Excel will mangle date columns and reorder rows. Edit them in a text editor or via Python.
- **Don't commit the regenerated XLSX without re-running the build script.** Drift between CSV and XLSX is a bug.
