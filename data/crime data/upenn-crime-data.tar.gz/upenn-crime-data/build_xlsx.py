import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

DATA_DIR = '/home/claude/upenn-crime-data/data'
OUT_PATH = '/home/claude/upenn-crime-data/output/upenn_crime_data.xlsx'

clery = pd.read_csv(f'{DATA_DIR}/penn_clery_annual.csv')
ucr = pd.read_csv(f'{DATA_DIR}/penn_pa_ucr.csv')
ppd = pd.read_csv(f'{DATA_DIR}/ppd_homicides_citywide.csv')
alerts = pd.read_csv(f'{DATA_DIR}/upennalerts.csv')
sources = pd.read_csv(f'{DATA_DIR}/data_sources.csv')

clery_wide = clery.pivot_table(index='crime_type', columns='year', values='count', aggfunc='first').reset_index()
clery_order = [
    'murder','rape','fondling','stalking','domestic_violence','dating_violence',
    'robbery','aggravated_assault','burglary','motor_vehicle_theft','arson',
    'liquor_arrest','liquor_disciplinary','drug_arrest','drug_disciplinary',
    'weapons_arrest','weapons_disciplinary','hate_crimes_total'
]
clery_wide['__sort'] = clery_wide['crime_type'].map({c:i for i,c in enumerate(clery_order)})
clery_wide = clery_wide.sort_values('__sort').drop(columns='__sort').reset_index(drop=True)

wb = Workbook()
wb.remove(wb.active)

bold = Font(name='Arial', bold=True)
header_fill = PatternFill('solid', start_color='1F4E78')
header_font = Font(name='Arial', bold=True, color='FFFFFF')
center = Alignment(horizontal='center')
left = Alignment(horizontal='left')
thin = Side(border_style='thin', color='CCCCCC')
border = Border(left=thin, right=thin, top=thin, bottom=thin)

def style_header(ws, row=1, ncols=None):
    if ncols is None:
        ncols = ws.max_column
    for c in range(1, ncols+1):
        cell = ws.cell(row=row, column=c)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center

def autosize(ws):
    for col_idx in range(1, ws.max_column+1):
        max_len = 8
        for row_idx in range(1, ws.max_row+1):
            v = ws.cell(row=row_idx, column=col_idx).value
            if v is not None:
                max_len = max(max_len, min(50, len(str(v))+2))
        ws.column_dimensions[get_column_letter(col_idx)].width = max_len

# ---- Sheet 1: README / overview
ws = wb.create_sheet('Overview')
ws['A1'] = 'UPenn / University City Crime Statistics — 2017-2024'
ws['A1'].font = Font(name='Arial', bold=True, size=14)
ws.merge_cells('A1:F1')
overview_rows = [
    [],
    ['Sheet','Description','Geography','Years','Source'],
    ['Clery_Wide','Penn Clery Act stats by year (wide format)','Penn Patrol Zone (30th-43rd, Market-Baltimore)','2017-2024','Penn Annual Security Reports'],
    ['Clery_Long','Same data in long format (year, crime_type, count)','Penn Patrol Zone','2017-2024','Penn Annual Security Reports'],
    ['Clery_Trends','YoY change for major Clery categories','Penn Patrol Zone','2017-2024','Calculated from Clery'],
    ['PA_UCR','Penn PA Uniform Crime Reporting (broader area)','Expanded area beyond campus','2017-2024','Penn ASRs (PA UCR table)'],
    ['PPD_Homicides','Philadelphia citywide homicides','Entire City of Philadelphia','2007-2025','phillypolice.com'],
    ['UPennAlerts','UPennAlert emergency notification counts','Penn Patrol Zone','2019-2021','Daily Pennsylvanian analytics'],
    ['Sources','Source URLs and retrieval metadata','—','—','—'],
    [],
    ['Notes:'],
    ['1) Clery 2015-2016 data not pulled here — backfill from https://ope.ed.gov/campussafety/ if needed (data avail back to 2005).'],
    ['2) The 2024 motor vehicle theft spike (208 in Penn Patrol Zone) reflects citywide Hyundai/Kia thefts that hit Philadelphia hard. Not a Penn-specific surge.'],
    ['3) PPD citywide homicides are the broadest reference: peak 562 in 2021 down to 222 in 2025. Penn area (Clery) had 0-1 per year throughout.'],
    ['4) The 2020 dip in liquor disciplinary referrals (62 vs ~370 typical) reflects COVID-era empty campus.'],
    ['5) PA UCR uses different geography (broader) and rates per 100k FTE — never compare Clery counts directly to PA UCR counts.'],
]
for row in overview_rows:
    ws.append(row)
for c in range(1, 6):
    ws.cell(row=3, column=c).font = header_font
    ws.cell(row=3, column=c).fill = header_fill
autosize(ws)

# ---- Sheet 2: Clery_Wide
ws = wb.create_sheet('Clery_Wide')
year_cols = sorted([c for c in clery_wide.columns if c != 'crime_type'])
ws.append(['crime_type'] + [str(int(y)) for y in year_cols])
for _, row in clery_wide.iterrows():
    ws.append([row['crime_type']] + [int(row[y]) if pd.notna(row[y]) else None for y in year_cols])
last_row = ws.max_row
total_row = last_row + 2
ws.cell(row=total_row, column=1, value='8yr_total')
ws.cell(row=total_row, column=1).font = bold
for col_idx, _ in enumerate(year_cols, start=2):
    col_letter = get_column_letter(col_idx)
    ws.cell(row=total_row, column=col_idx, value=f'=SUM({col_letter}2:{col_letter}{last_row})')
mean_row = total_row + 1
ws.cell(row=mean_row, column=1, value='8yr_avg')
ws.cell(row=mean_row, column=1).font = bold
for col_idx, _ in enumerate(year_cols, start=2):
    col_letter = get_column_letter(col_idx)
    ws.cell(row=mean_row, column=col_idx, value=f'=AVERAGE({col_letter}2:{col_letter}{last_row})')
    ws.cell(row=mean_row, column=col_idx).number_format = '0.0'
style_header(ws)
autosize(ws)
ws.freeze_panes = 'B2'

# ---- Sheet 3: Clery_Long
ws = wb.create_sheet('Clery_Long')
ws.append(list(clery.columns))
for _, row in clery.iterrows():
    ws.append([row[c] if pd.notna(row[c]) else None for c in clery.columns])
style_header(ws)
autosize(ws)
ws.freeze_panes = 'A2'

# ---- Sheet 4: Clery_Trends - YoY % changes for key categories
ws = wb.create_sheet('Clery_Trends')
trend_crimes = ['rape','fondling','robbery','aggravated_assault','burglary','motor_vehicle_theft','domestic_violence','dating_violence']
trend_df = clery_wide[clery_wide['crime_type'].isin(trend_crimes)].set_index('crime_type').reindex(trend_crimes).reset_index()
header = ['crime_type'] + [str(int(y)) for y in year_cols]
for y in year_cols[1:]:
    header.append(f'YoY_{int(y)}_pct')
ws.append(header)
for r_idx, (_, row) in enumerate(trend_df.iterrows(), start=2):
    ws.cell(row=r_idx, column=1, value=row['crime_type'])
    for c_idx, y in enumerate(year_cols, start=2):
        ws.cell(row=r_idx, column=c_idx, value=int(row[y]) if pd.notna(row[y]) else None)
    yoy_start_col = 2 + len(year_cols)
    for c_idx, y in enumerate(year_cols[1:], start=0):
        prev_letter = get_column_letter(2 + c_idx)
        curr_letter = get_column_letter(2 + c_idx + 1)
        target_col = yoy_start_col + c_idx
        ws.cell(row=r_idx, column=target_col,
                value=f'=IFERROR(({curr_letter}{r_idx}-{prev_letter}{r_idx})/{prev_letter}{r_idx},"")')
        ws.cell(row=r_idx, column=target_col).number_format = '0.0%'
style_header(ws)
autosize(ws)
ws.freeze_panes = 'B2'

# ---- Sheet 5: PA_UCR
ws = wb.create_sheet('PA_UCR')
ws.append(list(ucr.columns))
for _, row in ucr.iterrows():
    ws.append([int(row[c]) if c not in ('source_asr',) and pd.notna(row[c]) else row[c] for c in ucr.columns])

last_row = ws.max_row
rate_start_row = last_row + 3
ws.cell(row=rate_start_row-1, column=1, value='Part 1 rate per 100k FTE (calculated)').font = bold
ws.cell(row=rate_start_row, column=1, value='year')
ws.cell(row=rate_start_row, column=2, value='total_part1_per_100k_fte')
for offset, (_, row) in enumerate(ucr.iterrows(), start=1):
    excel_row = rate_start_row + offset
    src_excel_row = 1 + offset
    ws.cell(row=excel_row, column=1, value=int(row['year']))
    fte_letter = get_column_letter(list(ucr.columns).index('fte_population') + 1)
    total_letter = get_column_letter(list(ucr.columns).index('total_part1') + 1)
    ws.cell(row=excel_row, column=2,
            value=f'=({total_letter}{src_excel_row}/{fte_letter}{src_excel_row})*100000')
    ws.cell(row=excel_row, column=2).number_format = '0.0'
style_header(ws, row=1)
ws.cell(row=rate_start_row, column=1).font = header_font
ws.cell(row=rate_start_row, column=1).fill = header_fill
ws.cell(row=rate_start_row, column=2).font = header_font
ws.cell(row=rate_start_row, column=2).fill = header_fill
autosize(ws)
ws.freeze_panes = 'B2'

# ---- Sheet 6: PPD_Homicides
ws = wb.create_sheet('PPD_Homicides')
ws.append(list(ppd.columns) + ['yoy_change_pct','5yr_rolling_avg'])
for r_idx, (_, row) in enumerate(ppd.iterrows(), start=2):
    ws.cell(row=r_idx, column=1, value=int(row['year']))
    ws.cell(row=r_idx, column=2, value=int(row['homicides']))
    ws.cell(row=r_idx, column=3, value=row['source'])
    if r_idx > 2:
        ws.cell(row=r_idx, column=4, value=f'=IFERROR((B{r_idx}-B{r_idx-1})/B{r_idx-1},"")')
        ws.cell(row=r_idx, column=4).number_format = '0.0%'
    if r_idx >= 6:
        ws.cell(row=r_idx, column=5, value=f'=AVERAGE(B{r_idx-4}:B{r_idx})')
        ws.cell(row=r_idx, column=5).number_format = '0.0'
style_header(ws)
autosize(ws)
ws.freeze_panes = 'A2'

# ---- Sheet 7: UPennAlerts
ws = wb.create_sheet('UPennAlerts')
ws.append(list(alerts.columns))
for _, row in alerts.iterrows():
    ws.append([int(row['year']), int(row['upennalert_count']), row['source']])
style_header(ws)
autosize(ws)

# ---- Sheet 8: Sources
ws = wb.create_sheet('Sources')
ws.append(list(sources.columns))
for _, row in sources.iterrows():
    ws.append([row[c] for c in sources.columns])
style_header(ws)
for r in range(2, ws.max_row+1):
    for c in range(1, ws.max_column+1):
        ws.cell(row=r, column=c).alignment = Alignment(wrap_text=True, vertical='top')
ws.column_dimensions['A'].width = 18
ws.column_dimensions['B'].width = 50
ws.column_dimensions['C'].width = 60
ws.column_dimensions['D'].width = 14
ws.column_dimensions['E'].width = 60

wb.save(OUT_PATH)
print(f'wrote {OUT_PATH}')
