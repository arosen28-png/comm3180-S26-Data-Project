# Changelog

All notable changes to this dataset are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project follows a date-based versioning scheme (`YYYY.MM`) since releases align with annual reporting cycles.

---

## [2026.04] — 2026-04-26

### Added
- Initial public release.
- Penn Clery data 2017–2024 (transcribed from 2020, 2022, 2025 ASRs).
- Penn Pennsylvania UCR data 2017–2024.
- PPD citywide homicide totals 2007–2025 (YTD).
- UPennAlerts partial counts 2019–2021.
- `build_xlsx.py` to compile CSVs into a single 8-sheet workbook with formulas.
- Exploratory notebook `notebooks/01_explore.ipynb`.
- Slide deck `deliverables/upenn_crime_findings.pptx`.
- Documentation suite under `docs/` (FINDINGS, METHODOLOGY, DATA_DICTIONARY, GLOSSARY, SOURCES, CAVEATS, FAQ).

### Known issues
- 2015–2016 Clery data not included; ASRs for those years not in Penn's current public archive. Backfill via federal Campus Safety database documented in `docs/CAVEATS.md`.
- UPennAlerts coverage is partial (2019–2021 only). Penn does not publish a complete archive.
- Hate crime category breakdowns (race, religion, etc.) not captured; only annual totals.

---

## Unreleased

### Planned for [2026.11] (after October 2026 ASR publishes)
- 2025 Clery and PA UCR data.
- Updated 2025 PPD homicide year-end total.
- Refresh the slide deck and findings document with 2025 figures.

### Backlog (no committed timeline)
- Backfill 2015–2016 from federal Campus Safety database.
- Add a comparable Ivy League peer-school context table.
- Build out a UPennAlerts scraper to extend the alerts series.
- Layer in PPD incident-level data from Open Data Philly.
